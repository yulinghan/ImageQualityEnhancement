%% Simple example on Cameraman
%
%   We present here a normal and a fast version of our NLM-SAP
%   algorithm. The kernel used to compare the shapes is
%   trapezoidal. See also README.TXT in the associate zip file for
%   more details.
%
%   We use 3 isotropic Gaussian shapes. We illustrate the benefits
%   of combining the estimates based on different sizes rather than
%   using only a single one.
%
%   See also DEMO_NLMSAP.m, DEMO_NLMSAP_GAUSS_8DIRECTIONS.m
%
%   Copyright (C) 2011 NLM-SAP project
%   Authors: \( \textbf{C-A. Deledalle} \), \(\textbf{V. Duval} \) and
%   \(\textbf{J. Salmon} \)
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

close all
clear all
addpath('tools');
addpath('functions');

%% FAST version of the NLM-SAP

%% Parameters initialization
sig             = 20;            % standard-deviation of the noise
hW              = 5;             % half-size of the search window
alpha           = 0.7;           % h^2=alpha^2*sigma^2/2 for 7x7 patches
                                 % h^2 is adapted for other shapes in
                                 % proportion of the 0.99-quantile.

% Initialize random seed
randn('seed', 2);

%% Build the true and noisy images
img     = double(imread('cameraman.png'));
[M,N]   = size(img);
img_nse = img + sig * randn(size(img));

%% Build 3 disk shapes
L = 1;           % number of size levels
R = 4;           % radius of the first level (evolution as R*sqrt(2)^(n-1)
A = 0;           % number of angle partitions (precisely 2^A)
shapes = cat(3, ...
             build_pie(M,N,L,R/2,A), ...
             build_pie(M,N,L,R/sqrt(2),A), ...
             build_pie(M,N,L,R,A));

         
%% Display the shapes
figure
plot_shapes(shapes);
         
tic

%% Compute the 3 NL-Shapes estimations
[nlsum, sumphi, sumphi2, deriv] = ...
    NLMSAP_trapezoid(img_nse, hW, shapes, alpha, sig);
nbshapes = size(nlsum, 3);

%% Compute risks maps
riskmat = risk_var(sumphi, sumphi2);

%% Aggregation step with WAV
[img_fast_NLMSAP, beta_fast_NLMSAP] = aggregation_WAV(nlsum, riskmat);

toc


%% Display
figure('Position',[100 100  1400 800])
subplot(1,3,1)
plotimage(img_nse);
title('Noisy');
subplot(1,3,2);
plotimage(nlsum(:,:,2));
title('Estimate obtained with only one isotropic shape');
subplot(1,3,3);
plotimage(img_fast_NLMSAP);
title('Combination obtained by NLM-SAP');
linkaxes
