function res = psnr(hat, star, L)
%PSNR        Peak Signal to Noise Ratio
%   RES = MSE(HAT, STAR) computes the peak signal to noise ratio
%   between the estimation HAT and the truth STAR. HAT and STAR are
%   two 2D arrays.
%
%               PSNR = 10 log10[ 255^2 / MSE(HAT, STAR) ]
%
%   RES = MSE(HAT, STAR, L) computes the same as RES = MSE(HAT,
%   STAR) excpet the reference signal is L instead of 255
%
%               PSNR = 10 log10[ L^2 / MSE(HAT, STAR) ]
%
%   See also mse
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

    if nargin < 3
        L = 255;
    end

    res = 10 * log10(L^2 / mean2((hat - star).^2));

end
