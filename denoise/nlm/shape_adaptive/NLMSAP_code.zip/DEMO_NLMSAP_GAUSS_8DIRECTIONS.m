%% Simple example on Cameraman
%
%   We present here a normal and a fast version of our NLM-SAP
%   algorithm. The kernel used to compare the shapes is
%   trapezoidal. See also README.TXT in the associate zip file for
%   more details.
%
%   We use 8 directionnal quarter pies. We illustrate the benefits
%   of combining the estimates based on different shapes rather
%   than using only a single one.
%
%   See also DEMO_NLMSAP.m, DEMO_NLMSAP_FAST.m
%
%   Copyright (C) 2011 NLM-SAP project
%   Authors: \( \textbf{C-A. Deledalle} \), \(\textbf{V. Duval} \) and
%   \(\textbf{J. Salmon} \)
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

close all
clear all
addpath('tools');
addpath('functions');

%% Gaussian kernel's version of the NLM-SAP

%% Parameters initialization
sig             = 20;            % standard-deviation of the noise
hW              = 5;             % half-size of the search window
alpha           = 0.7;           % h^2=alpha^2*sigma^2/2 for 7x7 patches
                                 % h^2 is adapted for other shapes in
                                 % proportion of the 0.99-quantile.
temperature     = 0.4*sig.^2;    % Temperature for EWA

% Initialize random seed
randn('seed', 2);

%% Build the true and noisy images
img     = double(imread('cameraman.png'));
[M,N]   = size(img);
img_nse = img + sig * randn(size(img));

%% Build 8 directionnal quarter pies
L = 1;
R = 8;
A = 2;
shapes = build_pie(M,N,L,R,A);

tic

%% Compute the 8 NL-Shapes
[nlsum, sumphi, sumphi2, deriv] = ...
    NLMSAP_gauss(img_nse, hW, shapes, alpha, sig);
nbshapes = size(nlsum, 3);

%% Compute risks maps
riskmat = risk_sure(img_nse, nlsum, deriv, sig);

%% Filter  risks maps using Yaroslavsky approach
riskemp = (repmat(img_nse, [1 1 nbshapes]) - nlsum).^2;
divmat  = riskmat - riskemp;
[divmat_diff riskmat_diff] = riskfilter_yaroslavsky(divmat, riskmat);

%% Aggregation step with EWA
[result_EWA, beta_EWA] = aggregation_EWA(nlsum, divmat_diff, temperature);

toc

%% Display the 8 directions and the aggregated one in the center
x=25:125;
y=80:180;
images_8=[nlsum(x,y,8),nlsum(x,y,1),nlsum(x,y,2);...
          nlsum(x,y,7),result_EWA(x,y),nlsum(x,y,3);...
          nlsum(x,y,6),nlsum(x,y,5),nlsum(x,y,4)];

%% Display the shapes
figure
plot_shapes(shapes);

%% Display
figure
plotimage(images_8);
title(['Estimations obtained by 8 directional shapes and a ' ...
       'Gaussian kernel. Results of EWA aggregation in the ' ...
       'middle']);



