function plot_shapes(shapes)
%PLOT_SHAPES    Display shapes
%   PLOT_SHAPES(shapes) displays the shapes used for the NLM-SAP
%   algorithm. Shapes is a 3D arrays, the two fist dimensions
%   correspond on the spatial dimensions and the third dimension
%   corresponds on the different shapes.
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

    [M,N,nb] = size(shapes);
    [cM, cN] = fourier_center(M,N);
    [shapes cM cN] = crop(shapes, cM, cN);
    [M,N,nb] = size(shapes);
    k = 1;
    ncol = min(4,nb);
    nrow = ceil(nb/ncol);
    for k = 1:nb
        subplot(nrow,ncol,k);
        shapes(:,:,k) = shapes(:,:,k) / max2(shapes(:,:,k));
        img(:,:,1) = 1-shapes(:,:,k);
        img(:,:,2) = 1-shapes(:,:,k);
        img(:,:,3) = 1-shapes(:,:,k);
        img(cM,cN,1) = 1;
        img(cM,cN,2:3) = 0;
        image(img), axis image, axis off;
    end
    linkaxes;

function [res cM cN] = crop(shapes, cM, cN)

    res = shapes;
    if sum2(res(1, :, :)) == 0
        res = res(2:end, :, :);
        [res cM cN] = crop(res, cM - 1, cN);
    end
    if sum2(res(:, 1, :)) == 0
        res = res(:, 2:end, :);
        [res cM cN] = crop(res, cM, cN - 1);
    end
    if sum2(res(end, :, :)) == 0
        res = res(1:(end - 1), :, :);
        [res cM cN] = crop(res, cM, cN);
    end
    if sum2(res(:, end, :)) == 0
        res = res(:, 1:(end - 1), :);
        [res cM cN] = crop(res, cM, cN);
    end
