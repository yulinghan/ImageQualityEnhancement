function [nlsum, sumphi, sumphi2, deriv] = ...
        NLMSAP_gauss(img_nse, hW, shapes, alpha, sig)
%NLMSAP_GAUSS   NLM-SAP algorithm with Gaussian kernel
%   INPUT:
%     IMG_NSE    : Noisy image
%     HW         : Half width for the searching zone
%     SHAPES     : The family of shapes considered by the algorithm
%     ALPHA      : Parameter tuning the bandwidth h
%     SIG        : Standard deviation of the noise
%   OUTPUT:
%     IMG_FIL    : Denoised/filtered image
%     SUMPHI     : Pointwise normalization/denominator of the NLM-SAP
%     SUMPHI2    : Pointwise squared coefficients of the NLM-SAP
%     DERIV      : Pointwise derivative term of the NLM-SAP
%
%   [NLSUM, SUMPHI, SUMPHI2, DERIV] = NLMSAP_GAUSS(IMG_NSE, HW,
%   SHAPES, ALPHA, SIG) computes the NLM-SAP solution with general
%   shapes and the Gaussian kernel to compare the patches.
%
%   See also NLMSAP_trapezoid
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

[M,N] = size(img_nse);

%% Location of the central point of the kernel
[cM, cN] = fourier_center(M,N);

nbshapes = size(shapes,3);

%% Initialization
nlsum   = zeros(M,N,nbshapes);
sumphi  = zeros(M,N,nbshapes); % sum phi
sumphi2 = zeros(M,N,nbshapes); % sum phi2
deriv   = zeros(M,N,nbshapes);
ktype   = 1;
for kshape = 1:nbshapes
    fprintf(1, 'Apply NLM-SAP (Gaussian kernel) -- shape #%d\n', kshape);

    % Kernel(s) construction
    kernelZ     = shapes(:,:,kshape);
    f_kernelZ   = fft2(fftshift(kernelZ)); % Spectral kernel

    % Metric
    h2 = compute_h2(kernelZ, alpha, sig);
    f_kernel    = f_kernelZ / (2*h2);

    % Central weight
    central_weight = exp(-2*sig^2 / (2*h2)); % 1, without this correction

    % Initialization
    sumphiprime         = zeros(M, N ); % sum phi'
    nlprime             = zeros(M, N ); % sum u phiprime
    phiprime            = zeros(M, N );

    %% NLM Loop
    for dx = -hW:hW
        for dy = -hW:hW
            % Bounds of the valid zone in img and img translated
            % by the vector (dx, dy)
            % We assume periodic conditions
            x1range = 1:M;
            y1range = 1:N;
            x2range = mod([1:M]+dx-1,M)+1;
            y2range = mod([1:N]+dy-1,N)+1;

            img_nsedxdy = img_nse(x2range,y2range); % image translate

            if dx == 0 && dy == 0
                w = central_weight * ones(M,N);
            else
                % Square differences
                diff    = (img_nse-img_nsedxdy).^2;
                f_diff  = fft2(diff);

                % Convolution in Fourier domain
                %    dst(t)=sum_{tau in image} S(tau)diff(t+tau),
                % cf. eq (5) in "Non-Local Methods with
                % Shape-Adaptive Patches (NLM-SAP)", JMIV 2011
                dst     = real(ifft2(conj(f_kernel).* f_diff));
                w       = exp(-dst);
            end

            % Construct denoised patches
            nlsum(x1range,y1range,ktype ) = ...
                nlsum(x1range,y1range,ktype ) + ...
                w(x1range,y1range) .* ...
                img_nse(x2range,y2range);
            sumphi(x1range,y1range,ktype ) = ...
                sumphi(x1range,y1range,ktype ) + ...
                w(x1range,y1range);
            sumphi2(x1range,y1range,ktype ) = ...
                sumphi2(x1range,y1range,ktype ) + ...
                w(x1range,y1range).^2;

            % Compute the derivative of the NLM for the Gaussian Kernel
            phiprime(x1range,y1range ) = ...
                1/h2*(kernelZ(mod(cM -1,M)+1,mod(cN -1,N)+1) .* ...
                (img_nse(x1range,y1range) - ...
                img_nse(x2range,y2range)) + ...
                kernelZ(mod(cM -dx-1,M)+1,mod(cN -dy-1,N)+1) .* ...
                (img_nse(x1range,y1range) - ...
                img_nse(mod(x1range-dx-1,M)+1,...
                mod(y1range-dy-1,N)+1))) ...
                .*(-w(x1range,y1range));

            sumphiprime(x1range,y1range ) = ...
                sumphiprime(x1range,y1range ) + ...
                phiprime(x1range,y1range );
            nlprime(x1range,y1range ) = ...
                nlprime(x1range,y1range ) + ...
                phiprime(x1range,y1range ) .* ...
                img_nse(x2range,y2range);

        end
    end

    % computes NLmeans and the risk
    nlsum(:,:,ktype ) = nlsum(:,:,ktype ) ./ sumphi(:,:,ktype );
    deriv(:,:,ktype ) = central_weight + nlprime(:,:) - ...
        nlsum(:,:,ktype ).*sumphiprime(:,:);
    deriv(:,:,ktype ) = deriv(:,:,ktype )./sumphi(:,:,ktype );
    ktype = ktype + 1;
end
