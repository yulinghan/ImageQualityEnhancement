function riskmat = risk_sure(img_nse, nlsum, deriv, sig)
%RISK_SURE      Risk estimation using the SURE for NLM-SAP
%   INTPUT:
%     IMG_NSE : Noisy image
%     NLSUM   : NLM result
%     DERIV   : Divergence term for the NLM, needed for Stein's Lemma
%     SIG     : Standard deviation of the noise
%   OUTPUT:
%     RISKMAT : Risk term computed with Stein's Lemma
%
%   [RISKMAT] = RISK_SURE(IMG_NSE, NLSUM, DERIV, SIG) estimates the
%   risk of NLM-SAP using Stein's Unbiased Risk Estimation (SURE).
%   IMG_NSE should be a 2D array while NLSUM and DERIV are 3D
%   arrays. The two first dimensions of NLSUM and DERIV corresponds
%   on the dimension of IMG_NSE while the third correspond to the
%   different NL estimations.
%
%   See also risk_mse, risk_var
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.Authors: Deledalle, Duval, Salmon

nbshapes = size(nlsum, 3);
[M,N] = size(img_nse);

riskmat=zeros(M,N,nbshapes);
for ktype=1:nbshapes
     riskmat(:,:,ktype) = -sig.^2 + (2*sig.^2).*deriv(:,:,ktype) + ...
                          (img_nse-nlsum(:,:,ktype)).^2;
end
