function pie = build_pie(M,N,L,R0,A0)
%BUILD_PIE        Build "pie" shapes
%   INPUT:
%     M,N : Image size
%     L   : Number of levels of size
%     R   : Radius of the first level (evolution as R(2-1/2^n)
%     A   : Number of angle partition (precisely 2^A)
%   OUTPUT:
%     PIE : The pie shapes
%
%   PIE = BUILD_PIE(M,N,L,R0,A0) builds the pie shapes as described
%   on Figure 2 in "Non-Local Methods with Shape-Adaptive Patches
%   (NLM-SAP)", JMIV 2011.
%
%   See also BUILD_RECTANGLE
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.


    addpath('tools');
    k = 1;
    for kl = 1:L
        R = R0 * sqrt(2)^(kl - 1);
        A = A0 + kl - 1;
        for ka = 1:2^(A+1)
            pie(:,:,k) = build_part(M,N,L,R,A,ka,kl);
            pie(:,:,k) = pie(:,:,k) / sum2(pie(:,:,k));
            k = k + 1;
            if A == 0
                break
            end
        end
    end

function part = build_part(M,N,L,R,A,ka,kl)

    %% Location of the central point (0,0) in Fourier
    [cM, cN] = fourier_center(M,N);

    [x y] = meshgrid((1:(M+1)) - cM - 0.5, ...
                     (1:(N+1)) - cN - 0.5);
    V = is_in_part(M,N,L,R,A,ka,kl,x,y);

    part = zeros(M,N);
    for i = 1:M
        for j = 1:N
            v1 = V(j,i);
            v2 = V(j+1,i);
            v3 = V(j,i+1);
            v4 = V(j+1,i+1);
            if v1 == v2 && v1 == v3 && v1 == v4
                part(i,j) = v1;
                continue;
            end

            nb = 10;
            [x y] = meshgrid(((i+0.5/nb):1/nb:(i+1-0.5/nb)) - cM - 0.5, ...
                             ((j+0.5/nb):1/nb:(j+1-0.5/nb)) - cN - 0.5);
            part(i,j) = ...
                mean2(is_in_part(M,N,L,R,A,ka,kl,x,y));
        end
    end

function res = is_in_part(M,N,L,R,A,ka,kl,x,y)

    r2 = R^2;
    res = ((x.^2 + y.^2) <= r2);
    if A > 0
        ang = 2*pi/2^A;
        a1 = -cos(ka/2     * ang);
        b1 = sin(ka/2      * ang);
        a2 = -cos((ka/2+1) * ang);
        b2 = sin((ka/2+1)  * ang);
        c1 = min([(a1+b1)/2 (a1-b1)/2 (-a1+b1)/2 (-a1-b1)/2]);
        c2 = max([(a2+b2)/2 (a2-b2)/2 (-a2+b2)/2 (-a2-b2)/2]);
        res = ...
            (a1 * x + b1 * y + c1 <= 0) & ...
            (a2 * x + b2 * y + c2 > 0) & ...
            res;
    end
    if A > 1
        a3 = -(b1+b2);
        b3 = a1+a2;
        c3 = min([(a3+b3)/2 (a3-b3)/2 (-a3+b3)/2 (-a3-b3)/2]);
        res = ...
            (a3 * x + b3 * y + c3 < 0) & ...
            res;
    end
