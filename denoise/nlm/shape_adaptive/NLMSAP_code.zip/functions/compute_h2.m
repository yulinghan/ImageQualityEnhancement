function h2 = compute_h2(kernel, alpha, sig)
%COMPUTE_H2  Select h^2 using a Chi-square based choice
%   INPUT:
%     KERNEL  : Type of kernel used to compare the patches
%     ALPHA   : Tuning parameter to select the bandwidth at any
%               noise level
%     SIG     : Standard deviation of the noise
%   OUTPUT:
%     H2      : Value of h^2, the square of the bandwidth

%   H2 = COMPUTE_H2(KERNEL, ALPHA, SIG) select the value of the
%   parameter h^2 using a Chi-square based choice such that:
%       - H2 = ALPHA^2 * SIG^2 for patches of size 7x7, and
%       - P(Sim < Cst * H2) = 0.99 with Cst a constant.
%   This relevant for the Gaussian kernel in NLM-SAP. Do not use it
%   for the trapezoidal kernel.
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.


nb = sum2(kernel)^2/sum2(kernel.^2);
sizeref = 49;
qchi = 0.99;
n = @(nb) chi2inv(qchi, nb)/nb;
h2 = 2*sig^2*n(nb) * (alpha^2/2) / n(sizeref);
