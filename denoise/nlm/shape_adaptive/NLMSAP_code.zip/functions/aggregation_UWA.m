function [result, beta] = aggregation_UWA(nlsum)
%AGGREGATION_UWA        Uniform aggregation
%   INPUT:
%     NLSUM       : NLM result
%   OUTPUT:
%     RESULT      : Denoised image based on uniform aggregation
%     BETA        : Neighbors weights for each pixel
%
%   [RESULT, BETA] = AGGREGATION_UWA(NLSUM) uniformly averages the
%   estimate in NLSUM. RESULT is the resuting image while BETA
%   provides the weight at each pixel associated to each shape.
%
%   See also aggregagtion_EWA, aggregagtion_UWA, aggregagtion_WAV
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

beta = ones(size(nlsum)) / size(nlsum, 3);
result = mean(nlsum, 3);
