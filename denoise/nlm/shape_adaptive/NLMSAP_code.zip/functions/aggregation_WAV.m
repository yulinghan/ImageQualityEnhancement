function [result, beta] = aggregation_WAV(nlsum, riskmat)
%AGGREGATION_WAV        Aggregation using inverse variance weights
%   INPUT:
%     NLSUM       : NLM result
%     RISKMAT     : Risk term
%   OUTPUT:
%     RESULT      : Denoised image using inverse variance weights
%     BETA        : Neighbors weights for each pixel
%
%   [RESULT, BETA] = AGGREGATION_WAV(NLSUM, RISKMAT) combines the
%   estimates in NLSUM using inverse variance weights based on
%   RISKMAT. RESULT is the resuting image while BETA provides the
%   weight at each pixel associated to each shape.
%
%   See also aggregation_EWA, aggregagtion_MURE, aggregagtion_WAV
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

nbshapes = size(nlsum, 3);
beta = 1./riskmat;
beta = beta ./ repmat(sum(beta,3),[1 1 nbshapes]);
result = sum(beta .* nlsum, 3);
