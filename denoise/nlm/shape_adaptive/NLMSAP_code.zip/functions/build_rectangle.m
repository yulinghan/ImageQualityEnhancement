function rect = build_rectangle(M,N,nbrot,lr,lt,offset)
%BUILD_RECTANGLE        Build "rectangular" shapes
%   INPUT:
%     M,N     : Image size
%     NBROT   : Rotations number
%     LR      : Lenght in the u_r direction  (polar coordinates)
%     LT      : Lenght in the u_t direction  (polar coordinates)
%     OFFSET  : Shift in the u_theta direction (eg. 0 for centered square)
%     ROTSPEC : Special angle of rotation
%   OUTPUT:
%     RECT    : The rectangular shapes
%
%   RECT = BUILD_RECTANGLE(M,N,NBROT,LR,LT,OFFSET) builds
%   rectangular shapes as described on Figure 2 in "Non-Local
%   Methods with Shape-Adaptive Patches (NLM-SAP)", JMIV 2011.
%
%   See also BUILD_PIE
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

addpath('tools');

[cM,cN]=fourier_center(M,N);

urmax= lr/2; % max on ur
urmin= -lr/2;% min on ur
utmax= lt/2+offset;% max on utheta
utmin=-lt/2+offset;% min on utheta

[Y, X] = meshgrid([1:M],[1:N]);% WARNING: X is for the horizontal direction
X=X' -cN;Y=Y'-cM;%flipud(Y')-cM;


if (~exist('rotspec'))
    vecrot=1:nbrot;
    rect=zeros(M,N,nbrot);
    vectheta=-[0:nbrot-1]*2*pi/nbrot;
else % specified rotation number
    vecrot=rotspec;
    vectheta= -rotspec*pi/180; % the y-axis being inverted one needs to change the sign of theta
    rect=zeros(M,N,1);
end

for krot=1:length(vecrot)
    theta=vectheta(krot); % rotation angle (Ox, u_r)

    % First draft: binary image
    c=cos(theta);
    d=sin(theta);
    rect(:,:,krot)=double(c*X+d*Y>=urmin & c*X+d*Y<=urmax & -d*X+c*Y<=utmax & -d*X+c*Y>=utmin);

    % Second draft: improves the edge
    mask=[0,1,0;1,1,1;0,1,0];
    a=zeros(M,N);
    % Bounding box
    [irange,jrange]=ind2sub([M,N],find(rect(:,:,krot)>0));
    kmin=max(2,min(irange)-1);
    kmax=min(M-1,max(irange)+1);
    pmin=max(2,min(jrange)-1);
    pmax=min(M-1,max(jrange)+1);
    % Border
    for k=kmin:kmax
        for p=pmin:pmax
            a(k,p)= sum2(mask.*rect(k-1:k+1,p-1:p+1,krot))<5 & sum2(mask.*rect(k-1:k+1,p-1:p+1,krot))>0;
        end
    end

    ind=find(a);
    for k=1:length(ind)
        x=X(ind(k));
        y=Y(ind(k));
        [irange,jrange]=ind2sub([M,N],ind(k));
        rect(irange,jrange,krot)=zoompix(x,y,theta,urmax,urmin,utmax,utmin);
    end
    %Normalization
    rect(:,:,krot)=rect(:,:,krot)/sum2(rect(:,:,krot));
end

function out= zoompix(x,y,theta,urmax,urmin,utmax,utmin)
nscale=10; % Close up by a factor 10
c=cos(theta);
d=sin(theta);
[Yzoom, Xzoom] = meshgrid([1:nscale-1],[1:nscale-1]);
Xzoom=Xzoom'/nscale+x-0.5; Yzoom=flipud(Yzoom')/nscale+y-0.5;
recto= double(c*Xzoom+d*Yzoom>=urmin & c*Xzoom+d*Yzoom<=urmax & -d*Xzoom+c*Yzoom<=utmax & -d*Xzoom+c*Yzoom>=utmin);
out=sum2(recto)/(nscale-1).^2;
