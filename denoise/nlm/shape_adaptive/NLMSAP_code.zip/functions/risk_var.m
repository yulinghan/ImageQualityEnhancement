function riskmat = risk_var(sumphi, sumphi2)
%RISK_VAR       Risk estimation using the variance for NLM-SAP
%   INTPUT:
%     SUMPHI  : Pointwise normalization/denominator of theNLM-SAP

%     SUMPHI2 : Pointwise squared coefficients of the NLM-SAP
%   OUTPUT:
%     RISKMAT : Risk term measured through a variance approximation
%
%   [RISKMAT] = RISK_VAR(SUMPHI, SUMPHI2) estimates the risk of
%   NLM-SAP as its associated map of estimation variance. The
%   variance is approached at each pixel as:
%
%        VAR(x) = (sum_x' phi(x, x')^2) / (sum_x' phi(x, x'))^2
%
%   where phi(x, x') is the weight associated to x' in the search
%   window centered on x by NLM-SAP. SUMPHI and SUMPHI2 should be
%   arrays of the same size.
%
%   See also risk_mse, risk_sure
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

riskmat = (sumphi2./(sumphi.^2));
