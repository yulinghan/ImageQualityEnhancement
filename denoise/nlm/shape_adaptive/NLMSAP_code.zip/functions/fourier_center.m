function [cM, cN] = fourier_center(M, N)
%FOURIER_CENTER  Location the zero frequency in Fourier spectrums
%   INPUT:
%      M,  N  : Image size
%   OUTPUT:
%     cM, cN  : Location of the zero frequency
%
%   [CM, CN] = FOURIER_CENTER(M, N) find the zero frequency location
%   in a 2D array of size M x N.
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

%% WARNING : +1 shift  due to Matlab's convention for FFT

if mod(M,2) == 1
    cM = (M+3)/2;
else
    cM = (M+2)/2;
end
if mod(N,2) == 1
    cN = (N+3)/2;
else
    cN = (N+2)/2;
end