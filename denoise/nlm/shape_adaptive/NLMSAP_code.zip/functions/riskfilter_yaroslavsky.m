function [divmatfilt riskmatfilt] = riskfilter_yaroslavsky(divmat, ...
                                                           riskmat)
%RISKFILTER_YAROSLAVSKY   Yaroslavsky based Risk Regularization
%   INPUT:
%     DIVMAT       : Divergence term in Stein's Lemma
%     RISKMAT      : Risk estimate provided by Stein's Lemma
%   OUTPUT:
%     DIVMATFILT   : Filtered divergence term
%     RISKMATFILT  : Filtered risk term
%
%   [DIVMATFILT RISKMATFILT] = RISKFILTER_YAROSLAVSKY(DIVMAT,
%   RISKMAT) filters the input divergence term in Stein's Lemma
%   DIVMAT and the input risk estimate provided by Stein's Lemma
%   RISKMAT using the Yaroslavsky approach. The search window is of
%   size 11x11 and the bandwith parameter is automatically
%   estimated from the content of the divergence term with an
%   empirical approach. The filtered divergence term and the risk
%   term are respectively placed in DIVMATFILT and RISKMATFILT.
%
%   See also riskfilter_conv
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

[M,N,nbshapes] = size(riskmat);

hW = 5;

divmatfilt = zeros(M,N,nbshapes);
riskmatfilt = zeros(M,N,nbshapes);
for k = 1:nbshapes
    img_nse = divmat(:,:,k);

    img_nse(img_nse == 0) = min2(img_nse(img_nse > 0));
    % Empirical estimation of h
    diff_xy = (img_nse(1:(M-1),1:(M-1)) - img_nse(2:M,2:M)).^2;
    h = mean(diff_xy(diff_xy < quantile(diff_xy(:), 0.9)));
    norm = zeros(M,N);
    for dx = -hW:hW
        for dy = -hW:hW
            if dx^2+dy^2 <= hW^2
                xrange = mod((1:M) + dx - 1, M) + 1;
                yrange = mod((1:N) + dy - 1, N) + 1;
                dst = ((img_nse) - (img_nse(xrange, yrange))).^2;
                w = dst < 20*h;
                divmatfilt(:,:,k) = divmatfilt(:,:,k) + ...
                    w .* divmat(xrange, yrange, k);
                riskmatfilt(:,:,k) = riskmatfilt(:,:,k) + ...
                    w .* riskmat(xrange, yrange, k);
                norm = norm + w;
            end
        end
    end
    riskmatfilt(:,:,k) = riskmatfilt(:,:,k) ./ norm;
    divmatfilt(:,:,k) = divmatfilt(:,:,k) ./ norm;
end
