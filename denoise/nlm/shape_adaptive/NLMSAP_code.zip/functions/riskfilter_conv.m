function riskmatfilt = riskfilter_conv(riskmat, sizeconv)
%RISKFILTER_CONV   Convolution based Risk Regularization
%   INPUT:
%     RISKMAT      : Risk estimate provided by Stein's Lemma
%     SIZECONV     : Radius of the convolution disk
%   OUTPUT:
%     RISKMATFILT  : Filtered risk term
%
%   RISKMATFILT = RISKFILTER_CONV(RISKMAT, SIZECONV) filters the
%   risk estimate provided by Stein's Lemma using a convolution by
%   a disk of radius SIZECONV. The filtered risk term is placed in
%   RISKMATFILT.
%
%   See also riskfilter_yaroslavsky
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

[M,N] = size(riskmat(:,:,1));
nbshapes = size(riskmat, 3);
halfbloc = ceil((sizeconv - 1)/2);

riskmatfilt = zeros(M,N,nbshapes);
filtbloc = zeros(M,N);

filtbloc = build_pie(M,N,1,halfbloc,0);
filtbloc = fftshift(filtbloc ./ sum2(filtbloc));
f_filtbloc = fft2(filtbloc);

for ktype=1:nbshapes
    riskmatfilt(:,:,ktype) = ...
        real(ifft2(fft2(riskmat(:,:,ktype)) .* conj(f_filtbloc)));
end
