function [result, beta] = aggregation_EWA(nlsum, riskmat, ...
                                          temperature)
%AGGREGATION_EWA        Aggregation using EWA
%   INPUT:
%     NLSUM       : NLM result
%     RISKMAT     : Risk term
%     TEMPERATURE : Temperature parameter in the exponential weights
%   OUTPUT:
%     RESULT      : Denoised image based on EWA aggregation
%     BETA        : Neighbors weights for each pixel
%
%   [RESULT, BETA] = AGGREGATION_EWA(NLSUM, RISKMAT, TEMPERATURE)
%   combines the estimates in NLSUM using exponential weights
%   based on RISKMAT and TEMPERATURE. RESULT is the resuting image
%   while BETA provides the weight at each pixel associated to each
%   shape.
%
%   See also aggregagtion_MURE, aggregagtion_UWA, aggregagtion_WAV
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

nbshapes = size(nlsum, 3);

riskmat = riskmat - repmat(max(riskmat, [], 3), [1 1 nbshapes]);

beta = exp(-1/temperature * riskmat);
beta = beta ./ repmat(sum(beta,3),[1 1 nbshapes]);
result = sum(beta .* nlsum, 3);

[result_MURE, beta_MURE] = aggregation_MURE(nlsum, riskmat);

for i = 1:size(result, 1)
    for j = 1:size(result, 2)
        if isnan(result(i,j))
            beta(i, j, :) = beta_MURE(i, j, :);
        end
    end
end
result(isnan(result)) = result_MURE(isnan(result));
