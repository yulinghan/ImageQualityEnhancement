NLM Shape-Adaptive Patches (NLM-SAP)
====================================

Revision:	        05/18/2010
Author:                 C-A Deledalle, V. Duval, J. Salmon
Web page:               http://josephsalmon.org/code/index_codes.php?page=NLMSAP

NLM-SAP is a MATLAB software implementing the denoising algorithm NLM
Shape-Adaptive Patches (NLM-SAP) for images damaged by Gaussian noise
as presented in:

"Non-Local Methods with Shape-Adaptive Patches (NLM-SAP)"
C.-A. Deledalle, V. Duval, J. Salmon,
Journal of Mathematical Imaging and Vision, 2011

NLM-SAP is free software distributed under the GNU Public License
(GPL). NLM-SAP should be used only for nonprofit purposes. Any
unauthorized use of this software for industrial or profit-oriented
activities is expressively prohibited.

LICENSE
=======

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

See LICENSE.txt

HOW TO
======

The program has been written for MATLAB with the ImageProcessing
Toolbox and the Statistics Toolbox. Please, look at DEMO_NLMSAP.m
to use the standard version of NLM-SAP or DEMO_NLMSAP_fast.m to use
the faster version.

MAIN PROGRAM FILES
==================

The main program files are the followings:

- DEMO_NLMSAP.m :
  	A demonstration file illustrating our standard algorithm.

- DEMO_NLMSAP_fast.m :
	A demonstration file illustrating our fast version using only
	isotropic shapes.

- functions/NLMSAP_trapezoid.m :
  	The main function of our method. It computes the NLMSAP for
	any associated shapes using a trapezoidal kernel.

- functions/NLMSAP_gauss.m :
  	The main function of our method. It computes the NLMSAP for
	any associated shapes using the classical Gaussian kernel.

- functions/aggregation_EWA.m :
	A function used to aggregate the shape-based estimatesusing
	the EWA (Exponentially Weighted Aggregates).

- functions/aggregation_WAV.m :
	A function used to aggregate the shape-based estimates using
	weights inversely proportional to their estimated variance.

- functions/build_pie.m :
	A function building pie shapes.

- functions/build_rectangle.m :
	A function building rectangle shapes.

- functions/risk_sure.m :
	A function that computes the pixel-wise SURE (Stein Unbiased
	Risk Estimate) for our generalized non local method.

- functions/risk_var.m :
	A function that computes the pixel-wise variance estimate for
	our generalized non local methods.

- functions/riskfilter_yaroslavsky.m :
	A function used to regularize the SURE, using Yaroslavsky
	methodon the "noise method" part of the divergence.

- functions/plot_shapes.m :
	A function that displays the shapes used in the NLM-SAP.

CONTACT INFORMATION
===================

For any comment, suggestion or question please contact Charles-Alban
Deledalle, Vincent Duval or Joseph Salmon.

Charles-Alban Deledalle		charles.deledalle (at) gmail.com
Vincent Duval			vincent.ducal (at) telecom-paristech.fr
Joseph Salmon			joseph.salmon (at) duke.edu

Copyright (C) 2011 NLM-SAP project

See The GNU Public License (GPL) in LICENSE.txt

